package com.cg.ems.dto;



import java.time.LocalDate;



public class Employee {


	private String empID;

	private String empFirstName;

	private String empLastName;

	private LocalDate empDateofBirth;

	private LocalDate empDateofJoining;

	private int empDeptID;

	private String empGrade;

	private String empDesignation;

	private int empBasic;

	private String empGender;

	private String empMaritalStatus;

	private String empHomeAddress;

	private String empContactNum;

	private String mgrId;

	public Employee(String empID, String empFirstName, String empLastName,
			LocalDate empDateofBirth, LocalDate empDateofJoining,
			int empDeptID, String empGrade, String empDesignation,
			int empBasic, String empGender, String empMaritalStatus,
			String empHomeAddress, String empContactNum, String mgrId) {
		super();
		this.empID = empID;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empDateofBirth = empDateofBirth;
		this.empDateofJoining = empDateofJoining;
		this.empDeptID = empDeptID;
		this.empGrade = empGrade;
		this.empDesignation = empDesignation;
		this.empBasic = empBasic;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNum = empContactNum;
		this.mgrId = mgrId;
	}

	public String getEmpID() {
		return empID;
	}

	public void setEmpID(String empID) {
		this.empID = empID;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public LocalDate getEmpDateofBirth() {
		return empDateofBirth;
	}

	public void setEmpDateofBirth(LocalDate empDateofBirth) {
		this.empDateofBirth = empDateofBirth;
	}

	public LocalDate getEmpDateofJoining() {
		return empDateofJoining;
	}

	public void setEmpDateofJoining(LocalDate empDateofJoining) {
		this.empDateofJoining = empDateofJoining;
	}

	public int getEmpDeptID() {
		return empDeptID;
	}

	public void setEmpDeptID(int empDeptID) {
		this.empDeptID = empDeptID;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public int getEmpBasic() {
		return empBasic;
	}

	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}

	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}

	public String getEmpHomeAddress() {
		return empHomeAddress;
	}

	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}

	public String getEmpContactNum() {
		return empContactNum;
	}

	public void setEmpContactNum(String empContactNum) {
		this.empContactNum = empContactNum;
	}

	public String getMgrId() {
		return mgrId;
	}

	public void setMgrId(String mgrId) {
		this.mgrId = mgrId;
	}

	@Override
	public String toString() {
		return "ID : " + empID + "\nFirstName : " + empFirstName
				+ "\nLastName : " + empLastName + "\nDate of Birth : "
				+ empDateofBirth + "\nDate of Joining : " + empDateofJoining
				+ "\nDepartment ID : " + empDeptID + "\nGrade : " + empGrade
				+ "\nDesignation : " + empDesignation + "\nBasic : "
				+ empBasic + "\nGender : " + empGender + "\nMaritalStatus : "
				+ empMaritalStatus + "\nHomeAddress : " + empHomeAddress
				+ "\nContact Number : " + empContactNum + "\nManager Id : " + mgrId+"\n\n";
	}



}