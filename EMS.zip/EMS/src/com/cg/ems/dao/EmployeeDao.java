package com.cg.ems.dao;

import java.util.ArrayList;

import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.exception.EmployeeException;

public interface EmployeeDao {

	public Employee searchEmployeeById(String id);
	public ArrayList<Employee> searchEmployeeByFirstName(String fn);
	public ArrayList<Employee> searchEmployeeByLastName(String ln);
	public ArrayList<Employee> searchEmployeeByDeptId(int id);
	public ArrayList<Employee> searchEmployeeByGrade(String grade);
	public ArrayList<Employee> searchEmployeeByMaritalStatus(String ms);
	public ArrayList<Department> displayDepartment()throws EmployeeException;
	public ArrayList <GradeMaster> getGradeCodes()throws EmployeeException;
}
