package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;


public class EmployeeDaoImpl implements EmployeeDao{

	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	

	public EmployeeDaoImpl()
	{
		con=DBUtil.getConnection();
	}

	@Override
	public Employee searchEmployeeById(String id) {
		Employee e=null;
		String query="SELECT * FROM Employee WHERE Emp_Id=?";

		PreparedStatement ps;
		try {
			ps = con.prepareStatement(query);

			ps.setString(1,id);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn=rs.getString(2);
				String ln=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				String contactno=rs.getString(13);
				String mgrid=rs.getString(14);

				e=new Employee(id1,fn,ln,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);

			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}



		return e;
	}

	@Override
	public ArrayList<Employee> searchEmployeeByFirstName(String fn) {
		Employee e=null;
		String query="SELECT * FROM Employee WHERE Emp_First_Name =?";
		ArrayList<Employee> list=new ArrayList<Employee>();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(query);

			ps.setString(1,fn);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				String contactno=rs.getString(13);
				String mgrid=rs.getString(14);

				
				e=new Employee(id1,fn1,ln,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);

				list.add(e);

			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}



		return list;
	}

	@Override
	public ArrayList<Employee> searchEmployeeByLastName(String ln) {
		Employee e=null;
		String query="SELECT * FROM Employee WHERE Emp_Last_Name=?";
		ArrayList<Employee> list=new ArrayList<Employee>();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(query);

			ps.setString(1,ln);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				String contactno=rs.getString(13);
				String mgrid=rs.getString(14);

				e=new Employee(id1,fn1,ln1,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(e);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}



		return list;
	}

	@Override
	public ArrayList<Employee> searchEmployeeByDeptId(int id) {
		Employee e=null;
		String query="SELECT * FROM Employee WHERE Emp_Dept_ID =?";
		ArrayList<Employee> list=new ArrayList<Employee>();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(query);

			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				String contactno=rs.getString(13);
				String mgrid=rs.getString(14);

				e=new Employee(id1,fn1,ln1,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(e);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}


		return list;

	}

	@Override
	public ArrayList<Employee> searchEmployeeByGrade(String grade) {
		Employee e=null;
		String query="SELECT * FROM Employee WHERE Emp_Grade =?";
		ArrayList<Employee> list=new ArrayList<Employee>();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(query);

			ps.setString(1,grade);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade1=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				String contactno=rs.getString(13);
				String mgrid=rs.getString(14);


				e=new Employee(id1,fn1,ln1,dob,doj,deptid,grade1,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(e);

			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}



		return list;

	}

	@Override
	public ArrayList<Employee> searchEmployeeByMaritalStatus(String ms) {
		Employee e=null;
		String query="SELECT * FROM Employee WHERE Emp_Marital_Status  =?";
		ArrayList<Employee> list=new ArrayList<Employee>();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(query);
			ps.setString(1,ms);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade1=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				String contactno=rs.getString(13);
				String mgrid=rs.getString(14);

				e=new Employee(id1,fn1,ln1,dob,doj,deptid,grade1,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(e);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<Department> displayDepartment() throws EmployeeException
	{
		con = DBUtil.getConnection();
		ArrayList<Department>departmentList=new ArrayList<Department>();
		Department dept=null;
		try
		{
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM Department");
			
			while(rs.next())
			{
				dept=new Department(rs.getString(2),rs.getInt(1));
				
				departmentList.add(dept);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return departmentList;
		
	}

	@Override
	public ArrayList<GradeMaster> getGradeCodes() throws EmployeeException {
		con = DBUtil.getConnection();
		ArrayList<GradeMaster> grade=new ArrayList<GradeMaster>();
		try
		{
			pst=con.prepareStatement("SELECT * FROM Grade_Master");
			rs=pst.executeQuery();
			GradeMaster details;
			while(rs.next())
			{
				details=new GradeMaster(rs.getString(1),rs.getInt(3),rs.getInt(4));
				grade.add(details);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
			
		}
		return grade;
		
	}

}

