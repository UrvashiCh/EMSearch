package com.cg.ems.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;


public class MainEmployee
{
	static Scanner sc=new Scanner(System.in);
	static EmployeeService ems=null;
	static int choice=0;
	public static void main(String args[]) throws EmployeeException
	{  
		ems=new EmployeeServiceImpl();
		while(true)

		{
			System.out.println("\nWhat do you want to do \n");
			System.out.println("1.Search employee by id \n2.Search employee by first name \n3.Search Employee by last name \n4.Search Employee by Department Id \n5.Search Employee by grade \n6.Search employee by Marital Status \n");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:byId();
			break;
			case 2:byFirstName();
			break;
			case 3:byLastName();
			break;
			case 4:byDepartmentId();
			break;
			case 5:byGrade();
			break;
			case 6:byMaritalStatus();
			break;
			default:System.exit(1);
			}}
	}
	public static void byId() throws EmployeeException
	{
		String id;
		do {
			System.out.println("Enter the id of employee to be searched");
			id=sc.next();
			if(!ems.validateEmpId(id))
			{
				System.out.println("Employee ID Should be 6 digits:");
			}
		}while(!ems.validateEmpId(id));

		Employee e=ems.searchEmployeeById(id);
		if(e==null)
			System.out.println("No Employee with such id exists");
		else
			System.out.println(e);
	}

	public static void byFirstName() throws EmployeeException
	{
		String fn;
		do
		{
			System.out.println("Enter the first name of the employee to be searched");
			fn=sc.next();
			if(!ems.validateName(fn))
			{
				System.out.println("Invalid First Name, Should start with Capital");
			}}while(!ems.validateName(fn));

		ArrayList<Employee> list=ems.searchEmployeeByFirstName(fn);
		if(list.size()==0)
			System.out.println("No Record found");
		else
		{
			Iterator iterator = list.iterator();
			while(iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		}



	}

	public static void byLastName() throws EmployeeException
	{
		String ln;
		do
		{
			System.out.println("Enter the last name of the employee to be searched");
			ln=sc.next();
			if(!ems.validateLastName(ln))
				System.out.println("Invalid Last Name, Should start with Capital");
		}while(!ems.validateLastName(ln));

		ArrayList<Employee> list=ems.searchEmployeeByLastName(ln);
		if(list.size()==0)
			System.out.println("No Record found");
		else
		{
			Iterator iterator = list.iterator();
			while(iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		}

	}

	
	public static void byDepartmentId() throws EmployeeException
	{
		int id;
		ArrayList<Department> depList;
		ArrayList <Integer> validateDepId=new ArrayList<Integer>();
		depList=ems.displayDepartment();
        System.out.println("Select department id from these");
        
		for(Department dep:depList)
		{
			validateDepId.add(dep.getDeptID());
		}
		System.out.println(validateDepId);
        do
        {
		System.out.println("Enter the department id of the employee to be searched");
		id=sc.nextInt();
		
		if(!ems.validateDeptID(validateDepId,id))
		{
			System.out.println("Enter a valid department id");
		}
        }while(!ems.validateDeptID(validateDepId,id));
		ArrayList<Employee> e=ems.searchEmployeeByDeptId(id);
		if(e.size()==0)
			System.out.println("No Record found");
		else
		{
			Iterator iterator = e.iterator();
			while(iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		}


	}

	public static void byGrade() throws EmployeeException
	{
		String grade;
		ArrayList<GradeMaster> Code = null;
	    Code = ems.getGradeCodes();
	    ArrayList <String> validateGradeCode=new ArrayList<String>();
	    System.out.println("Select Grades from these");
	    for(GradeMaster code:Code)
		{
			validateGradeCode.add(code.getGradeCode());
		}
		System.out.println(validateGradeCode);
		do {
			
		System.out.println("Enter the grade of the employee to be searched");
		grade=sc.next();
		if(!ems.isValidGradeCode(validateGradeCode, grade))
		{
			System.out.println("Enter a valid grade");
		}
		}while(!ems.isValidGradeCode(validateGradeCode, grade));
		ArrayList<Employee> list=ems.searchEmployeeByGrade(grade);
		if(list.size()==0)
			System.out.println("No Record found");
		else
		{
			Iterator iterator = list.iterator();
			while(iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		}

	}

	public static void byMaritalStatus() throws EmployeeException
	{
		String eMarStatus=null;
		int status;
	do
	{
		System.out.println("Select Maritial Status:\n 1. Single\n 2. Married\n 3. Divorced\n 4. Seperated\n 5. Widowed");
		status=sc.nextInt();
		if(!ems.isValidMaritalStatus(status))
		{
			System.out.println("Entered Maritial Status is not valid:\n \n");
		}
		else if(ems.isValidMaritalStatus(status))
		{
           switch(status)
			{
			case 1: eMarStatus="S";
			break;
			case 2: eMarStatus="M";
			break;
			case 3: eMarStatus="D";
			break;
			case 4: eMarStatus="S";
			break;
			case 5: eMarStatus="W";
			break;
			}
		}
	}while(!ems.isValidMaritalStatus(status));
		
		ArrayList<Employee> list=ems.searchEmployeeByMaritalStatus(eMarStatus);
		if(list.size()==0)
			System.out.println("No Record found");
		else
		{
			Iterator iterator = list.iterator();
			while(iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		}

	}
}