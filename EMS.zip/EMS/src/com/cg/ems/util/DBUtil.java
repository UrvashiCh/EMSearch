package com.cg.ems.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

	static Connection con;
	static
	{
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@127.0.0.1:1521:xe";
			String user="system";
			String passwd="Capgemini123";
			con=DriverManager.getConnection(url,user,passwd);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	public static Connection getConnection()
	{
		return con;
	}
}

