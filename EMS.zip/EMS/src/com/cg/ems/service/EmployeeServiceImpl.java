package com.cg.ems.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao dao;

	public EmployeeServiceImpl()
	{
		dao=new EmployeeDaoImpl();
	}
	@Override
	public Employee searchEmployeeById(String id) {

		return dao.searchEmployeeById(id);
	}

	@Override
	public ArrayList<Employee> searchEmployeeByFirstName(String fn) {

		return dao.searchEmployeeByFirstName(fn);
	}

	@Override
	public ArrayList<Employee> searchEmployeeByLastName(String ln) {

		return dao.searchEmployeeByLastName(ln);
	}

	@Override
	public ArrayList<Employee> searchEmployeeByDeptId(int id) {

		return dao.searchEmployeeByDeptId(id);
	}

	@Override
	public ArrayList<Employee> searchEmployeeByGrade(String grade) {

		return dao.searchEmployeeByGrade(grade);
	}

	@Override
	public ArrayList<Employee> searchEmployeeByMaritalStatus(String ms) {

		return dao.searchEmployeeByMaritalStatus(ms);
	}
	@Override
	public boolean validateEmpId(String empId) throws EmployeeException
	{
		String empIdPattern="[0-9]{6}";
		if(Pattern.matches( empIdPattern,empId))
		{
			return true;
		}
		else
		{
			//throw new EmployeeException("Invalid Employee ID, should have only 6 digits:\n\n\n");
		return false;
		}
	}
	@Override
	public boolean validateName(String empName) throws EmployeeException {

		String empNamePattern="[A-Z][a-z]+";
		if(Pattern.matches(empNamePattern,empName))
		{
			return true;
		}
		else
		{
			return false;
		
	}
	}
	@Override
	public boolean validateLastName(String empName) throws EmployeeException {
		String empNamePattern="[A-Z][a-z]+";
		if(Pattern.matches(empNamePattern,empName))
		{
			return true;
		}
		else
		{
			return false;
		
	}
}
	@Override
	public boolean validateDeptID(ArrayList<Integer> validateDepId, int depId) throws EmployeeException {
		if(validateDepId.contains(depId))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	@Override
	public ArrayList<Department> displayDepartment() throws EmployeeException {
		
		return dao.displayDepartment();
	}
	@Override
	public ArrayList<GradeMaster> getGradeCodes() throws EmployeeException {
		
		return dao.getGradeCodes();
	}
	@Override
	public boolean isValidGradeCode(ArrayList<String> validateGradeCode, String gradeCode) throws EmployeeException {
		if(validateGradeCode.contains(gradeCode))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	@Override
	public boolean isValidMaritalStatus(int status) throws EmployeeException {
		if(status<=5 && status>=1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}


