package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.GradeMaster;
import com.cg.ems.exception.EmployeeException;

public interface EmployeeService {
	public Employee searchEmployeeById(String id);
	public ArrayList<Employee> searchEmployeeByFirstName(String fn);
	public ArrayList<Employee> searchEmployeeByLastName(String ln);
	public ArrayList<Employee> searchEmployeeByDeptId(int id);
	public ArrayList<Employee> searchEmployeeByGrade(String grade);
	public ArrayList<Employee> searchEmployeeByMaritalStatus(String ms);
	public boolean validateEmpId(String empId) throws EmployeeException;
	public boolean validateName(String empName) throws EmployeeException;
	public boolean validateLastName(String empName) throws EmployeeException;
	public boolean validateDeptID(ArrayList <Integer>validateDepId,int depId)throws EmployeeException;
	public ArrayList<Department> displayDepartment()throws EmployeeException;
	public ArrayList <GradeMaster> getGradeCodes()throws EmployeeException;
	public boolean isValidGradeCode(ArrayList <String>validateGradeCode,String gradeCode)throws EmployeeException;
	public boolean isValidMaritalStatus(int status)throws EmployeeException;
}

